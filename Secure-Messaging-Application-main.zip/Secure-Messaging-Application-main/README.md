# Secure-Messaging-Application
The Secure Messaging App is a peer-to-peer (P2P) desktop application designed to facilitate confidential communication between users using end-to-end encryption (E2EE). It ensures that messages are securely exchanged over the network and securely stored on the local device. The application is built using Python and PySide6
